# TBB-DDOS
IT,S A POWERFUL DDOS ATTACK TOOL


# SETUP 

    pkg update && upgrade
    pkg install git
    pkg install nodejs-lts  
    rm -rf TBB-DDOS
    git clone https://github.com/TeamBlackBerry/TBB-DDOS
    cd TBB-DDOS
    npm i requests
    npm i https-proxy-agent
    npm i crypto-random-string
    npm i events
    npm i fs
    npm i net
    npm i cloudscraper
    npm i request
    npm i hcaptcha-solver
    npm i randomstring
    npm i cluster
    npm i cloudflare-bypasser
    pip3 install -r requirements.txt
    pkg install golang 

# RUN 
    python TBB-DDOS.py 

    
